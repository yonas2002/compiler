package parser;

import lexer.Token;
import lexer.TokenType;
import parsetree.ParseTreeNode;

import java.util.List;

public class Parser {

    private List<Token> tokens;    
    private int position =0;

    public Parser(List<Token> tokens) {
        this.tokens = tokens;
    }

    private Token currentToken(){
        return tokens.get(position);
    }

    private Token peek(int offset){
        int index = position + offset;
        return index < tokens.size() ? 
        tokens.get(index) : 
        tokens.get(tokens.size() - 1); // Return last token if out of bounds
    }

    private Token consume(TokenType type){
        Token token = currentToken();
        if(token.type != type){
            throw new RuntimeException(
                String.format("Expected token type %s but found %s at position %d", 
                type, token.type, position)
            );
        }
        position++;
        return token;
    }

    private boolean isDataType(Token token){
        if(token.type != TokenType.KEYWORD){
            return false;
        }
        switch(token.value){
            case "int":
            case "float":
            case "char":
            case "double":
            case "string":
            case "void":
            case "boolean":
                return true;
            default:
                return false;
        }
    }
    
    private boolean isAtEnd() { 
        return currentToken().type == TokenType.EOF; 
    }

    /** Entry point — kept for backward compat with CompilerGUI */
    public ParseTreeNode parseDeclaration() {
        return parseProgram(); 
    }

    /** program → declaration* | assignment* */
    public ParseTreeNode parseProgram() {
        ParseTreeNode root = new ParseTreeNode("program", "Program");
        while (!isAtEnd()) {
            if (isDataType(currentToken()))
                root.addChild(parseDeclarationRule());
            else if (currentToken().type == TokenType.IDENTIFIER
                    && peek(1).type == TokenType.OPERATOR && peek(1).value.equals("="))
                root.addChild(parseAssignment());
            else
                throw new RuntimeException("Syntax Error: Unexpected token '" + currentToken().value + "'");
        }
        return root;
    }

    /** declaration → datatype IDENTIFIER (= expression)? ; */
    private ParseTreeNode parseDeclarationRule() {
        ParseTreeNode node = new ParseTreeNode("declaration", "Declaration");
        Token dt = currentToken(); consume(TokenType.KEYWORD);
        node.addChild(new ParseTreeNode(dt.value, "Datatype"));
        Token id = currentToken(); consume(TokenType.IDENTIFIER);
        node.addChild(new ParseTreeNode(id.value, "Identifier"));
        if (currentToken().type == TokenType.OPERATOR && currentToken().value.equals("=")) {
            consume(TokenType.OPERATOR);
            node.addChild(parseExpression());
        }
        consume(TokenType.PUNCTUATOR); // ;
        return node;
    }

    /** assignment → IDENTIFIER = expression ; */
    private ParseTreeNode parseAssignment() {
        ParseTreeNode node = new ParseTreeNode("assignment", "Assignment");
        Token id = currentToken(); consume(TokenType.IDENTIFIER);
        node.addChild(new ParseTreeNode(id.value, "Identifier"));
        consume(TokenType.OPERATOR); // =
        node.addChild(parseExpression());
        consume(TokenType.PUNCTUATOR); // ;
        return node;
    }

    /** expression → term ((+ | -) term)* */
    private ParseTreeNode parseExpression() {
        ParseTreeNode node = new ParseTreeNode("Expression", "expression");
        node.addChild(parseTerm());
        while (!isAtEnd() && currentToken().type == TokenType.OPERATOR
               && (currentToken().value.equals("+") || currentToken().value.equals("-"))) {
            Token op = currentToken(); consume(TokenType.OPERATOR);
            node.addChild(new ParseTreeNode("Operator", op.value));
            node.addChild(parseTerm());
        }
        return node;
    }

    /** term → factor ((* | /) factor)* */
    private ParseTreeNode parseTerm() {
        ParseTreeNode node = new ParseTreeNode("Term", "term");
        node.addChild(parseFactor());
        while (!isAtEnd() && currentToken().type == TokenType.OPERATOR
               && (currentToken().value.equals("*") || currentToken().value.equals("/"))) {
            Token op = currentToken(); consume(TokenType.OPERATOR);
            node.addChild(new ParseTreeNode("Operator", op.value));
            node.addChild(parseFactor());
        }
        return node;
    }

    /** factor → NUMBER | IDENTIFIER | ( expression ) */
    private ParseTreeNode parseFactor() {
        Token tok = currentToken();
        if (tok.type == TokenType.NUMBER) {
            consume(TokenType.NUMBER); 
            return new ParseTreeNode("Number", tok.value);
        } 
        else if (tok.type == TokenType.IDENTIFIER) {
            consume(TokenType.IDENTIFIER); 
            return new ParseTreeNode("Identifier", tok.value);
        } 
        else if(tok.type == TokenType.STRING){
            consume(TokenType.STRING);
            return new ParseTreeNode(tok.value, "String");
        }
        else if (tok.type == TokenType.PUNCTUATOR && tok.value.equals("(")) {
            consume(TokenType.PUNCTUATOR);
            ParseTreeNode expr = parseExpression();
            consume(TokenType.PUNCTUATOR);
            return expr;
        }
        throw new RuntimeException("Syntax Error: Expected number or identifier but found '" + tok.value + "'");
    }

}
