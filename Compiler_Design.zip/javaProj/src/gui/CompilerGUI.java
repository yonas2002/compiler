package gui;

import lexer.*;
import parser.Parser;
import parsetree.ParseTreeNode;
import semantics.SemanticAnalyzer;
import semantics.SemanticError;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class CompilerGUI extends JFrame {

    JTextArea inputArea;
    JTextArea outputArea;

    public CompilerGUI() {

        setTitle("Compiler Design Assignment");
        setSize(1200, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayeredPane(getLayeredPane());

        inputArea = new JTextArea();
        inputArea.setFont(new Font("Monospaced", Font.PLAIN, 18));
        inputArea.setBackground(Color.BLACK);
        inputArea.setForeground(Color.WHITE);

        outputArea = new JTextArea();
        outputArea.setFont(new Font("Monospaced", Font.BOLD, 16));
        outputArea.setBackground(Color.DARK_GRAY);
        outputArea.setForeground(Color.WHITE);
        outputArea.setEditable(false);

        JScrollPane inputScrollPane = new JScrollPane(inputArea);
        inputScrollPane.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Color.GRAY),
            "Input Code"));
        
        JScrollPane outputScrollPane = new JScrollPane(outputArea);
        outputScrollPane.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Color.GRAY),
            "Output"));

        JSplitPane splitPane = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT,
                inputScrollPane,
                outputScrollPane
            );

        splitPane.setDividerLocation(600);
        splitPane.setResizeWeight(0.5);
        splitPane.setOneTouchExpandable(true);
        splitPane.setContinuousLayout(true);


        JButton compileButton =
                new JButton("Compile");

        compileButton.setFont(
            new Font("Arial", Font.BOLD, 16)
        );
        compileButton.addActionListener(e -> compileCode());

        setLayout(new BorderLayout());

        add(compileButton, BorderLayout.NORTH);
        add(splitPane, BorderLayout.CENTER);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void compileCode() {
        String code = inputArea.getText().trim();
        if (code.isEmpty()) { outputArea.setText("No input provided."); return; }
        outputArea.setText("");

        // Phase 1: Lexical Analysis
        outputArea.append("=== PHASE 1: LEXICAL ANALYSIS ===\n");
        outputArea.append(String.format("%-20s %s\n", "Token Type", "Value"));
        outputArea.append(String.format("%-20s %s\n", "----------", "-----"));
        Lexer lexer = new Lexer(code);
        List<Token> tokens = lexer.tokenize();
        for (Token t : tokens)
            if (t.type != TokenType.EOF)
                outputArea.append(String.format("%-20s %s\n", t.type, t.value));

        // Phase 2: Syntax Analysis
        outputArea.append("\n=== PHASE 2: SYNTAX ANALYSIS ===\n");
        ParseTreeNode tree;
        try {
            tree = new Parser(tokens).parseDeclaration();
            outputArea.append("Syntax Analysis: OK\n\nParse Tree:\n");
            outputArea.append(tree.treeToString("  "));
        } catch (RuntimeException ex) {
            outputArea.append("FAILED: " + ex.getMessage() + "\n"); return;
        }

        // Phase 3: Semantic Analysis
        outputArea.append("\n=== PHASE 3: SEMANTIC ANALYSIS ===\n");
        try {
            SemanticAnalyzer sa = new SemanticAnalyzer();
            sa.analyze(tree);
            outputArea.append("Semantic Analysis: OK\n");
            outputArea.append(sa.getLog());
            outputArea.append("\nSymbol Table:\n");
            outputArea.append(sa.getSymbolTable().tableToString());
        } catch (SemanticError se) {
            outputArea.append("Semantic Error: " + se.getMessage() + "\n");
        }
    }
}