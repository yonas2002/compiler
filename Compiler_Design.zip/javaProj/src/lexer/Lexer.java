package lexer;

import java.util.ArrayList;
import java.util.List;

public class Lexer{

    private String input;
    private int position = 0;

    private final String[] keywords = {
        "int", "float",  "char",
        "if", "else", "while", "for",
        "return", "double",
        "void", "string", "boolean", "public",
        "private", "class", "static", "do"
    };

    public Lexer(String input){
        this.input = input;
    }

    public List<Token> tokenize(){

        List<Token> tokens = new ArrayList<>();

        while(position <input.length()){

            char current = input.charAt(position);

            if(Character.isWhitespace(current)){
                position++;
            }

            else if(Character.isLetter(current)){

                String word = readWord();

                if(isKeyword(word)){
                    tokens.add(new Token(TokenType.KEYWORD, word));
                }
                else{
                    tokens.add(new Token(TokenType.IDENTIFIER, word));
                }
            }

            else if(Character.isDigit(current)){

                String number = readNumber();
                tokens.add(new Token(TokenType.NUMBER, number));
            }

            else if(current == '"'){
                tokens.add(new Token(TokenType.STRING, readStringLiteral('"')));
            }

            else if(current == '\''){
                tokens.add(new Token(TokenType.STRING, readStringLiteral('\'')));
            }
            
            else if ((current == '+' || current == '-' || current == '*' ||
            current == '/' || current == '=' || current == '<' ||
             current == '>' || current == '!')){
                
                tokens.add(new Token(TokenType.OPERATOR, 
                    String.valueOf(current)));
                position++;
            }
            
            else if (";(){}".contains(String.valueOf(current))){

                tokens.add(new Token(TokenType.PUNCTUATOR, 
                    String.valueOf(current)));
                position++;
            }

            else if ("%&".contains(String.valueOf(current))){

                tokens.add(new Token(TokenType.SPECIALCHARACTER, 
                    String.valueOf(current)));
                position++;
            }

            else{
                System.out.println("Unrecognized character: " + current);
                position++;
            }

        }

        tokens.add(new Token(TokenType.EOF, ""));

        return tokens;
    }

    private String readStringLiteral(char quote){
        StringBuilder sb = new StringBuilder();
        sb.append(quote);
        position++;

        while(position < input.length()){
            char ch = input.charAt(position);
            if(ch == '\\' && position + 1 < input.length()){
                sb.append(ch);
                position++;
                sb.append(input.charAt(position));
                position++;
            }
            else if(ch == quote){
                sb.append(ch);
                position++;
                break;
            }
            else{
                sb.append(ch);
                position++;
            }
        }

        return sb.toString();

    }

    private String readWord(){

        StringBuilder sb = new StringBuilder();

        while(position < input.length() &&
              (Character.isLetterOrDigit(input.charAt(position)) || input.charAt(position) == '_')){

            sb.append(input.charAt(position));
            position++;
        }

        return sb.toString();
    }

    private String readNumber(){

        StringBuilder sb = new StringBuilder();

        while(position < input.length() &&
              Character.isDigit(input.charAt(position))){

            sb.append(input.charAt(position));
            position++;
        }

        if(position < input.length() && input.charAt(position) == '.' &&
            position + 1 < input.length() && Character.isDigit(input.charAt(position + 1))){

        sb.append(input.charAt(position)); // append '.'
        position++;

        while(position < input.length() &&
              Character.isDigit(input.charAt(position))){

            sb.append(input.charAt(position));
            position++;
        }
    }
        return sb.toString();
    }

    private boolean isKeyword(String word){

        for(String keyword : keywords){
            if(keyword.equals(word)){
                return true;
            }
        }
        return false;
    }

}