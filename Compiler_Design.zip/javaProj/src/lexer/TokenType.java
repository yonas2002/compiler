package lexer;

public enum TokenType{
    KEYWORD,
    IDENTIFIER,
    NUMBER,
    OPERATOR,
    STRING,
    PUNCTUATOR,
    SPECIALCHARACTER,
    EOF 
}