package semantics;

import java.util.*;

public class ScopeManager {
 
    private Stack<String> scopeStack = new Stack<>();
    private int scopeCounter = 0;

    public ScopeManager() {
        scopeStack.push("global");
    }

    public void enterScope(String name){
        scopeStack.push(name + "_" + scopeCounter++);
    }

    public void exitScope(){
        if (scopeStack.size() > 1) {
            scopeStack.pop();
        }
    }

    public String currentScope(){
        return scopeStack.isEmpty() ? "global" : scopeStack.peek();
    }

}
