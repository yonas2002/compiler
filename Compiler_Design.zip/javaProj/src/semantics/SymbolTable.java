package semantics;

import java.util.HashMap;
import java.util.Map;
import java.util.Collection;

public class SymbolTable {
    
    private Map<String, Symbol> table = new HashMap<>();

    public void insert(Symbol symbol){
        table.put(symbol.getName(), symbol);
    }

    public Symbol lookup(String name){
        return table.get(name);
    }

    public boolean contains(String name){
        return table.containsKey(name);
    }

    public Collection<Symbol> getAllSymbols(){
        return table.values();
    }

    public String tableToString(){
        if(table.isEmpty()) {
            return "SymbolTable is empty.";
        }
        StringBuilder sb = new StringBuilder();
        for (Symbol symbol : table.values()) {
            sb.append(symbol.toString()).append("\n");
        }
        return sb.toString();
    }
}
