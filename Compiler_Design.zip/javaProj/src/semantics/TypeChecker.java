package semantics;

public class TypeChecker {
    
    private SymbolTable symbolTable;

    public TypeChecker(SymbolTable symbolTable){
        this.symbolTable = symbolTable;
    }

        // Checks if the  RHS type of the value being assigned is compatible with the variable's declared type
    public String checkAssignment(String name, String rhsType){
        Symbol symbol = symbolTable.lookup(name);

        if(symbol == null){
            return "Variable " + name + " not declared.";
        }

        String varType = symbol.getType();
        if(!isCompatible(varType, rhsType)){
            return "Type error: Cannot assign " + rhsType + " to " + varType;
        }

        return "Assignment is valid.";
    }

    private boolean isCompatible(String lhs, String rhs){
        if(lhs.equals(rhs)){
            return true;
        }

        if(lhs.equals("float") && rhs.equals("int")){
            return true;
        }

        if(lhs.equals("double") && (rhs.equals("int") || rhs.equals("float"))){
            return true;
        }

        return false;
    }

    public String inferLiteralType(String literal){
        
        try {
            Integer.parseInt(literal);
            return "int";
        } catch (NumberFormatException e) {
        }

        try {
            Float.parseFloat(literal);
            return "float";
        } catch (NumberFormatException e) {
        }

        if(literal.startsWith("\"") &&
            literal.endsWith("\"")){
                return "string";
            }

        if(literal.startsWith("'") &&
            literal.endsWith("'")){
                return "char";
            }

        return "unknown";
    }
}
