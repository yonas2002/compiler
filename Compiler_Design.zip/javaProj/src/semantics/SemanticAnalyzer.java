package semantics;

import parsetree.*;

import java.util.*;

public class SemanticAnalyzer {
    
    private SymbolTable symbolTable;
    private ScopeManager scopeManager;
    private TypeChecker typeChecker;
    private StringBuilder log;

    public SemanticAnalyzer() {
        this.symbolTable = new SymbolTable();
        this.scopeManager = new ScopeManager();
        this.typeChecker = new TypeChecker(symbolTable);
        this.log = new StringBuilder();
    }

    public void analyze(ParseTreeNode root){
        log.setLength(0); 
        visit(root);
    }

    public void visit(ParseTreeNode node){
        if(node == null){
            return;
        }

        switch(node.getType()){
            case "Declaration":
                handleDeclaration(node);
                break;

            case "Assignment":
                handleAssignment(node);
                break;
            case "Identifier":
                handleIdentifier(node);
                break;
            default:
                for (ParseTreeNode child : node.getChildren()){
                    visit(child);
                }
        }
    }

    private void handleDeclaration(ParseTreeNode node){
        List<ParseTreeNode> children = node.getChildren();

        if(children.size() < 2){
            throw new RuntimeException("Invalid declaration node");
        }

        String type = children.get(0).getValue();
        String name = children.get(1).getValue();
        String scope = scopeManager.currentScope();

        if(symbolTable.lookup(name) != null){
            
            log.append("ERROR: Variable ")
            .append(name)
            .append(" already declared\n");
            return;
        }

        Symbol symbol = new Symbol(name, type, scope);
        symbolTable.insert(symbol);

        log.append("Declared: ").
        append(symbol).
        append("\n");

        for (int i = 2; i < children.size(); i++){
            visit(children.get(i));
        }
    }

    private void handleAssignment(ParseTreeNode node){

        List<ParseTreeNode> children = node.getChildren();

       if(children.isEmpty()){
           throw new RuntimeException("Invalid assignment node");
       }
    
       String name = children.get(0).getValue();

       if(symbolTable.lookup(name) == null){

            log.append("ERROR: Variable ").
            append(name).append(" not declared\n");

           return;
       }

       if(children.size() > 1){
        String rhsType = typeChecker.inferLiteralType(children.get(1).getValue());
        if(!rhsType.equals("unknown")){
        typeChecker.checkAssignment(name, rhsType);
       }
        
       log.append("Assigned: ").append(name).append("\n");
         for (int i = 1; i < children.size(); i++){
              visit(children.get(i));
         }
        }

}

    private void handleIdentifier(ParseTreeNode node){
        String name = node.getValue();
        
        if(symbolTable.lookup(name) == null){
            System.out.println("Variable " + name + " not declared.");
            return;
        }
        log.append("Identifier: ").append(name).append("\n");
    }

    public SymbolTable getSymbolTable() {
        return symbolTable;
    }

    public String getLog() {
        return log.toString();
    }
    
}
    
