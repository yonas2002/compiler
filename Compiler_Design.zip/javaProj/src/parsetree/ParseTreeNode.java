package parsetree;

import java.util.ArrayList;
import java.util.List;


public class ParseTreeNode {
    
    private String type;
    private String value;
    private List<ParseTreeNode> children;

    public ParseTreeNode(String value, String type){
        this.type = type;
        this.value = value;
        this.children = new ArrayList<>();
    }

    public ParseTreeNode(String value){
        this.type = "LEAF";
        this.value = value;
        this.children = new ArrayList<>();
    }

    public String getType() {
        return type;
    }
    public String getValue() {
        return value;
    }
    public List<ParseTreeNode> getChildren() {
        return children;
    }

    public void addChild(ParseTreeNode childNode){
        children.add(childNode);
    }

    public void printTree(String indentNode){
        System.out.println(indentNode + type + ": " + value);
        for (ParseTreeNode child : children) {
            child.printTree(indentNode + "  ");
        }
    }   

    public String treeToString(String indentNode){
        StringBuilder sb = new StringBuilder();
        sb.append(indentNode).append(type).append(": ").append(value).append("\n");
        for (ParseTreeNode child : children) {
            sb.append(child.treeToString(indentNode + "  "));
        }
        return sb.toString();
    }
}
